
export function formateDate(time){
    if (!time){return ''}
    let date = new Date(time)
    let dateStr = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes() + ':'
    if (date.getSeconds() < 10) {
        dateStr = dateStr + '0' + date.getSeconds()
    }else {
        dateStr = dateStr + date.getSeconds()
    }
    return dateStr
}