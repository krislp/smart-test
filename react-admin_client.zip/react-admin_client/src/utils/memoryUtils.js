/*
保存内存中数据的模块
*/

export default {
    user : {}  // 用户信息
}