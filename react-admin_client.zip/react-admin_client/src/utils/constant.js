/*
定义常量
*/
export const PAGE_SIZE = 3
export const BASE_IMG_URL = 'http://222.209.214.86:9002/upload'  // 上传图片的基础路径