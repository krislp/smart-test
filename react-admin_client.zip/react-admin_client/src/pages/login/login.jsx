import React, {Component} from 'react';
import './login.less';
import logo from '../../assets/images/logo.png';
import { Form, Icon, Input, Button } from 'antd';
import { reqLogin } from '../../api';
import {message} from 'antd';
import memoryUtils from '../../utils/memoryUtils';
import storageUtils from '../../utils/storageUtils';
import {Redirect} from 'react-router-dom'

const Item = Form.Item  // 不能写在import前

class Login extends Component {
    constructor(props){
        super(props);
        this.state={}
    }
    /*
    async和await
    1.作用：
        简化promiss对象的使用：不再使用then()来指定成功/失败的回调函数
        以同步编码（没有回调函数）方式实现异步流程
    2.哪里写await
        在返回promiss的表达式左侧写await
    3.哪里写async
        await所在函数（最近的）
    */
    handleSubmit = (event) => {
        event.preventDefault();
        this.props.form.validateFields(async (err, value) => {
            if (!err){
                // 校验成功
                // 发送登录请求
                const {username, password} = value;
                const result = await reqLogin(username, password);
                if(result.status === 0){
                    // 获取user信息
                    const user = result.data
                    // 保存user信息到内存中
                    memoryUtils.user = user
                    storageUtils.setUser(user)
                    // 跳转到管理界面（不需要再回退到登录）
                    this.props.history.replace('/')
                }else{
                    // 提示错误信息
                    message.success(result.msg)
                }
            }else{
                // 校验失败
                console.log('校验失败')
            }
        })
    }

    validatePwd = (rule, value, callback) => {
        if (!value) {
            callback('请输入密码')
        }else if (value.length < 4){
            callback('密码至少为4位')
        }else if(value.length > 12){
            callback('密码最多为12位')
        }else if(!/^[a-zA-Z0-9]+$/.test(value)){
            callback('密码只能由字母、数字、下划线组成')
        }else{
            callback()  // 验证通过
        }
    }

    render() {
        // 判断用户是否登录
        const user = memoryUtils.user
        if (user && user._id){
            // 内存中存在user，跳转到管理页面
            return <Redirect to='/'/>
        }
        const form = this.props.form;
        const { getFieldDecorator } = form;
        return (
            <div className='login'>
                <header className='login-header'>
                    <img src={logo} alt='logo'></img>
                    <h1>React项目：后台管理系系统</h1>
                </header>
                <section className='login-content'>
                    <h2>用户登录</h2>
                    
                    <Form onSubmit={this.handleSubmit} className="login-form">
                        <Item>
                            {getFieldDecorator('username', {
                                // 声明式验证
                                rules: [
                                    { required: true, whitespace:true, message: '请输入用户名' },
                                    { min: 4, message: '用户名必须大于4位' },
                                    { max: 12, message: '用户名必须小于12位' },
                                    { pattern: /^[a-zA-Z0-9]+$/, message: '用户名必须由字母、数字、下划线组成' },
                                    
                                ],
                            })(
                                <Input
                                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                                placeholder="用户名"
                                size='large'
                            />
                            )}
                            
                        </Item>
                        <Form.Item>
                            {getFieldDecorator('password', {
                                // 校验规则：自定义验证
                                rules: [{ validator: this.validatePwd }],
                            })(
                                <Input
                                prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                                type="password"
                                placeholder="密码"
                                size='large'
                            />
                            )}
                            
                        </Form.Item>
                        <Form.Item>
                            <Button type="primary" htmlType="submit" className="login-form-button" size='large'>
                                登录
                            </Button>
                        </Form.Item>
                    </Form>
                    
                </section>
            </div>
        );
    }
}

/*
高阶组件
1）本质是一个函数
2）接受一个组件（被包装组件），返回一个新的组件（包装组件），包装组件会向被包装组件传入特定属性
3）作用：扩展组件的功能
4）高阶组件也是高阶函数：接受一个组价函数，返回一个新的组件函数
*/
/*
包装Form组件生成一个新的Form(Login)
新组件会向Form组件传递一个强大的对象属性：form
*/
const WrappedNormalLoginForm = Form.create()(Login);

export default WrappedNormalLoginForm;


