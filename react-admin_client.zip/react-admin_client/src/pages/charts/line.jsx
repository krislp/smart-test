import React from 'react';

export default class Line extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div>
                Line
            </div>
        );
    }
}
