import React from 'react';

export default class Pie extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div>
                Pie
            </div>
        );
    }
}