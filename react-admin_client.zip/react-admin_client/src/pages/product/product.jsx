import React from 'react';
import {Switch, Route, Redirect} from 'react-router-dom';
import ProductHome from './home';
import ProductAddUpdate from './add-update';
import ProductDetail from './detail';
import './product.less'

export default class Product extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <Switch>
                {/* 
                    路由逐层匹配，如'/product/detail'会匹配到'/product'
                    如果要完全匹配需要加上 exact
                */}
                <Route path='/product' component={ProductHome} exact></Route>
                <Route path='/product/detail' component={ProductDetail} exact></Route>
                <Route path='/product/addupdate' component={ProductAddUpdate} exact></Route>
                <Redirect to='/product' />
            </Switch>
        );
    }
}