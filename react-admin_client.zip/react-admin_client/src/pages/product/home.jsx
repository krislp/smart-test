import React, {Component} from 'react';
import {Card, Table, Select, Button, Icon, message} from 'antd';
import LinkButton from '../../components/link-button';
import { reqProducts, reqSearchProducts, reqUpdateProductStatus } from '../../api';
import { PAGE_SIZE } from '../../utils/constant';

class ProductHome extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            searchType: 'productName',
            searchName: '',
            loading: false,
            total: 0,
            list: []
         };
    }


    initColumns = () => {
        this.columns= [
            {
                title: '商品名称',
                dataIndex: 'name',
            },
            {
                title: '商品描述',
                dataIndex: 'desc',
            },
            {
                width: 100,
                title: '价格',
                render: (product) => (<span>¥{product.price}</span>),
            },
            {
                width: 100,
                title: '状态',
                render: (product) => (
                    <span>
                        <Button type='primary' onClick={this.updateProductStatus.bind(this, product)}>{product.status===1 ? '下架' : '上架'}</Button>
                        <span>{product.status===1 ? '在售' : '已下架'}</span>
                    </span>
                    
                    
                ),
            },
            {
                width: 80,
                title: '操作',
                render: (product) => (
                    <span>
                        <LinkButton onClick={() => {this.props.history.push('/product/detail', {product})}}>详情</LinkButton>
                        <LinkButton onClick={() => {this.props.history.push('/product/addupdate', product)}}>修改</LinkButton>
                    </span>
                    
                    
                ),
            },
        ]
    }

    /*
    获取商品数据
    */
    getProducts = async (pageNum, pageSize) => {
        // 保存当前所在页码
        this.pageNum = pageNum
        this.setState({loading: true})
        pageSize = pageSize ? pageSize : PAGE_SIZE
        let result
        const {searchName, searchType} = this.state
        if (searchName){
            // 按条件搜索
            result = await reqSearchProducts(pageNum, pageSize, searchName, searchType)
        
        }else {
            // 常规搜索
            result = await reqProducts({pageNum, pageSize})
        }
        this.setState({loading: false})
        if (result.status===0){
            const {list, total} = result.data
            this.setState({list: list, total: total})
       }
   }

   // 更新商品状态
   updateProductStatus = async (product) => {
       const {_id, status, name} = product
       const newStatus = status===1 ? 2: 1
       const result = await reqUpdateProductStatus(_id, newStatus)
       if (result.status===0){
           message.success('更新' + name + '状态成功')
           this.getProducts(this.pageNum)
       }
   }

    componentWillMount () {
        this.initColumns()
    }

    componentDidMount () {
        this.getProducts(1, PAGE_SIZE)
    }

    render() {
        const Option = Select.Option
        const title = (
            <span>
                <Select 
                    defaultValue='productName' 
                    onChange={ value => {this.setState({searchType: value})}}
                >
                    <Option value='productName'>按名称搜索</Option>
                    <Option value='productDesc'>按描述搜索</Option>
                </Select>
                <input 
                    placeholder='关键字' 
                    style={{margin: '0 15px'}} 
                    onChange={ event =>{this.setState({searchName: event.target.value})}}
                />
                <Button type='primary' onClick={this.getProducts.bind(this, 1, PAGE_SIZE)}>搜索</Button>
            </span>
        )
        const extra = (
            <Button type='primary' onClick={() => {this.props.history.push('/product/addupdate')}}>
                <Icon type='plus'></Icon>
                <span>添加商品</span>
            </Button>
        )

        const {list, total, loading} = this.state
        const pageNum = this.pageNum
        return (
            <Card title={title} extra={extra}>
                <Table 
                    loading={loading}
                    rowKey='_id'
                    dataSource={list} 
                    columns={this.columns}
                    bordered
                    pagination={{total: total, onChange: this.getProducts, pageSize: PAGE_SIZE, current: pageNum}}
                />
            </Card>
        );
    }
}

export default ProductHome;