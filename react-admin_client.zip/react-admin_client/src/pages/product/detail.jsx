import React, {Component} from 'react';
import {Card, Icon, List} from 'antd';
import LinkButton from '../../components/link-button';
import {BASE_IMG_URL} from '../../utils/constant'
import { reqCategory } from '../../api';

const Item = List.Item

class ProductDetail extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            cName1: '',  // 当前商品的一级分类名称
            cName2: ''  // 当前商品的二级分类名称
         };
    }

    async componentDidMount () {
        const {categoryId, pCategoryId} = this.props.location.state.product
        if (pCategoryId==='0'){
            // 一级分类商品
            const result = await reqCategory(categoryId)
            const cName2 = result.data.name
            this.setState({cName2})
        }else {
            // 二级分类商品
            // 通过多个await方式发多个请求，后一个请求须等待前一个请求执行完成才下发，很耗时
            // const result1 = await reqCategory(pCategoryId)
            // const result2 = await reqCategory(categoryId)
            // console.log('result1')
            // console.log(result1)
            // console.log('result2')
            // console.log(result2)
            
            // 一次发送多个请求，只有都成果，才处理
            const results = await Promise.all([reqCategory(pCategoryId), reqCategory(categoryId)])
            // 当前数据有问题，无法读取到数据，后期修正
            // const cName1 = results[0].data.name
            // const cName2 = results[1].data.name
            const cName1 = '一级目录'
            const cName2 = '二级目录'
            this.setState({cName1, cName2})
        }
    }
    
    render() {
        const {name, desc, detail, imgs, price} = this.props.location.state.product
        const title = (
            <span>
                <LinkButton onClick={() => {this.props.history.goBack()}}>
                    <Icon type='arrow-left' style={{margin: '0 10px 0 0'}}></Icon>
                    <span>商品详情</span>
                </LinkButton>
                
            </span>
        )
        const {cName1, cName2} = this.state
        return (
            <Card title={title} className='product-detail'>
                <List>
                    <Item>
                        <span className='left'>商品名称：</span>
                        <span>{name}</span>
                    </Item>
                    <Item>
                        <span className='left'>商品描述：</span>
                        <span>{desc}</span>
                    </Item>
                    <Item>
                        <span className='left'>商品价格：</span>
                        <span>{price}元</span>
                    </Item>
                    <Item>
                        <span className='left'>商品分类：</span>
                        <span>{cName1} ---> {cName2} </span>
                    </Item>
                    <Item>
                        <span className='left'>商品图片：</span>
                        <span>
                            {imgs.map((img) => (
                                <img src={BASE_IMG_URL + img} alt='productImg'></img>
                            ))}
                        </span>
                    </Item>
                    <Item>
                        <span className='left'>商品详情：</span>
                        <span dangerouslySetInnerHTML={{__html: {detail}}}></span>
                    </Item>
                </List>
            </Card>
        );
    }
}

export default ProductDetail;