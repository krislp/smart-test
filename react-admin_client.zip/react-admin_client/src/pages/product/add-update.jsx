import React, {Component} from 'react';
import {
    Card,
    Icon,
    Form,
    Input,
    Button,
    Cascader
} from 'antd';
import LinkButton from '../../components/link-button';
import { reqCategorys } from '../../api';
import PicturesWall from './pictures-wall';

const {Item} = Form
const {TextArea} = Input

class ProductAddUpdate extends Component {
    constructor(props) {
        super(props);
        this.pw = React.createRef()
        this.state = { 
            options: []
         };
    }


    // 验证价格的自定义函数
    validatePrice = (rule, value, callback) => {
        // 过去的value是string类型， 通过*1转为数字
        if (value * 1 > 0){
            callback()  // 通过校验
        } else {
            callback('价格必须大于0')  // 未通过校验
        }
    }

    // 用于加载下一级列表的回调函数
    loadData = async selectedOptions => {
        // 得到选中的option对象
        const targetOption = selectedOptions[selectedOptions.length - 1];
        // 显示loading
        targetOption.loading = true;
        // 根据当前选中的分类，获取二级分类列表
        const subCategorys = await this.getCategorys(targetOption.value)
        // 隐藏loading
        targetOption.loading = false;

        if (subCategorys && subCategorys.length > 0){  // 当前选中的分类存在二级列表
            targetOption.children = subCategorys.map(s => ({
                label: s.name,
                value: s._id,
                isLeaf: true
            }))
        }else {  // 当前选中的分类不存在二级列表
            targetOption.isLeaf = true
        }

        // 更新options状态
        this.setState({
            options: [...this.state.options],
          })
      }

    // 根据categorys初始化options
    ininOptions = async (categorys) => {
        const options = categorys.map(c => ({
            value: c._id,
            label: c.name,
            isLeaf: false,
        }))
        // 如果是一个二级分类商品的修改
        const {pCategoryId} = this.product
        if (this.isUpdate && pCategoryId !=='0'){
            // 获取对应的二级分类列表
            const subCategorys = await this.getCategorys(pCategoryId)
            // 生成二级列表的options
            const childOptions = subCategorys.map(s => ({
                label: s.name,
                value: s._id,
                isLeaf: true
            }))
            // 获取当前商品对应的option
            const targetOption = options.find(option => option.value===pCategoryId)
            // 关联到对应的一级option上
            targetOption.children = childOptions
        }
        // 保存options状态
        this.setState({options})
    }

    // 异步获取一级/二级分类列表，并显示
    // async函数的返回值是一个新的promise对象，promise的结果和值由async的结果来决定
    getCategorys = async (parantId) => {
        const result = await reqCategorys(parantId)
        if (result.status===0){
            const categorys = result.data
            if (parantId==='0'){
                this.ininOptions(categorys)
            }else {
                return categorys  // 此处async返回的promise会成功并且value为categorys；
            }
            
        }
    }

    // 表单提交
    handleSubmit = () => {
        // 表单内容验证，如果通过才发请求
        this.props.form.validateFields((error, value) => {
            if(!error){
                const images = this.pw.current.getImages()
                console.log(images)
            }else{

            }
        })
    }

    componentWillMount () {
        // 取出携带的state
        const product = this.props.location.state  // 如果是添加商品，product没值，如果是修改商品，product有值
        // 保存是否是修改商品的标识
        this.isUpdate = !!product  // 强转为true或false
        // 保存product对象
        this.product = product || {}
    }

    componentDidMount () {
        this.getCategorys('0')
    }

    render() {
        const title = (
            <span>
                <LinkButton onClick={() => this.props.history.goBack()}>
                    <Icon type='arrow-left'></Icon>
                    <span>  {this.isUpdate ? '修改商品': '添加商品'}</span>
                </LinkButton>
            </span>
        )
        // 指定Item布局的配置对象
        const formItemLayout = {
            labelCol: {span: 2 },  // 左侧label的宽度
            wrapperCol: {span: 6}  // 指定右侧包裹的宽度
        }

        const { getFieldDecorator } = this.props.form;

        const {categoryId, pCategoryId, imgs} = this.product
        const categoryIds = []
        if (this.isUpdate){
            if (pCategoryId==='0'){  // 一级分类
                categoryIds.push(categoryId)
            }else {  // 二级分类
                categoryIds.push(pCategoryId)
                categoryIds.push(categoryId)
            }    
        }
        
        return (
            <Card title={title}>
                <Form {...formItemLayout} >
                    <Item  label="商品名称">
                        {getFieldDecorator('productName', {
                            initialValue: this.product.name,
                            // 添加校验规则
                            rules: [{required: true, message: "请输入商品名称"}]
                        })(<Input placeholder="请输入商品名称"/>)}
                    </Item>

                    <Item  label="商品描述">
                        {getFieldDecorator('productDesc', {
                            initialValue: this.product.desc,
                            rules: [{required: true, message: "请输入商品描述"}]
                        })(<TextArea placeholder="请输入商品描述" autoSize={{ minRows: 2, maxRows: 5 }}/>)}
                    </Item>

                    <Item  label="商品价格">
                        {getFieldDecorator('productPrice', {
                            initialValue: this.product.price,
                            rules: [{required: true, message: "请输入商品价格"}, 
                                    {validator: this.validatePrice}]
                        })(<Input type='number' placeholder="请输入商品价格" addonAfter="元"/>)}
                    </Item>

                    <Item label="商品分类">
                        {getFieldDecorator('productCategory', {
                            initialValue: categoryIds,
                            rules: [{required: true, message: "请选择商品分类"}]
                        })(
                            <Cascader
                                options={this.state.options}  // 一级列表的数据列表
                                loadData={this.loadData}
                            />
                        )} 
                    </Item>

                    <Item label="商品图片">
                        <PicturesWall ref={this.pw} imgs={imgs}/>  
                    </Item>

                    <Item label="商品详情">
                        <span>商品详情</span>
                    </Item>

                    <Item>
                        <Button type='primary' onClick={this.handleSubmit}>提交</Button>
                    </Item>
                </Form>
            </Card>
        );
    }
}

export default Form.create()(ProductAddUpdate);

/*
1.子组件调用父组件的方法：将父组件的方法以函数形式传递给子组件，子组件就可以调用
2.父组件调用子组件的方法：在父组件中通过ref得到子组件标签对象（也就是组件对象），调用其方法
*/