import React from 'react';
import PropTypes from 'prop-types';
import { Upload, Icon, Modal, message } from 'antd';
import { reqDeleteImage } from '../../api';
import { BASE_IMG_URL } from '../../utils/constant';

function getBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
  });
}

export default class PicturesWall extends React.Component {

    static propTypes = {
        imgs: PropTypes.array
    }

    

    constructor(props){
        super(props);
        let fileList = []
        // 如果传入了imgs
        const {imgs} = this.props
        if (imgs && imgs.length > 0){
            fileList = imgs.map((img, index) => ({
                uid: -index,  // 每个file有唯一id，如自定义，建议设置为负数
                name: img,  // 图片名称
                status: 'done',  // 图片状态 done - 已上传, removed - 已删除
                url: BASE_IMG_URL + img,  // 图片地址
            }))
        }
        this.imgs = props.imgs
        this.state = {
            previewVisible: false,  // 标识是否显示大图预览Modal
            previewImage: '',  // 大图的url
            fileList
        }
    }

    state = {
        previewVisible: false,  // 标识是否显示大图预览Modal
        previewImage: '',  // 大图的url
        fileList: [
        //   {
        //     uid: '-1',  // 每个file有唯一id，如自定义，建议设置为负数
        //     name: 'image.png',  // 图片名称
        //     status: 'done',  // 图片状态 done - 已上传 
        //     url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',  // 图片地址
        //   }
        ],
    };

    // 隐藏大图Modal的函数
    handleCancel = () => this.setState({ previewVisible: false });

    handlePreview = async file => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        // 显示指定file对应的大图
        this.setState({
            previewImage: file.url || file.thumbUrl,
            previewVisible: true,
        });
    };

    /*
    file：当前操作的文件图片（上传/删除）
    fileList：所有已上传文件图片的数组
    */
    handleChange = async ({ file, fileList }) => {
        // 一旦上传成功，将当前上传的file的数据进行纠正
        if(file.status==='done'){
            const result = file.response
            if(result.status===0){
                message.success('图片上传成功')
                const {name, url} = result.data
                file = fileList[fileList.length-1]
                file.name = name
                file.url = url.replace('http://localhost:5000', 'http://222.209.214.86:9002')
            }else{
                message.error('图片上传失败')
            }
        }else if (file.status==='removed'){
            const result = await reqDeleteImage(file.name)
            if (result.status===0){
                message.success('图片删除成功')
            }else{
                message.error('图片删除失败')
            }
        }
        // 在操作过程中更新fileList（上传/下载）
        this.setState({ fileList })
    }

    // 获取所有已上传文件名称
    getImages = () => {
        return this.state.fileList.map(file => file.name)
    }

    render() {
        const { previewVisible, previewImage, fileList } = this.state;
        const uploadButton = (
            <div>
                <Icon type="plus" />
                <div className="ant-upload-text">Upload</div>
            </div>
        );
        return (
            <div className="clearfix">
                {/*上传图片 */}
                <Upload
                    action="/manage/img/upload"  // 请求地址
                    accept='image/*'  // 只接收图片类型
                    name='image'  // 请求参数名
                    listType="picture-card"  // 内容样式
                    fileList={fileList}  // 已经上传的文件列表数组
                    onPreview={this.handlePreview}
                    onChange={this.handleChange}
                >
                    {/*限制文件数量 */}
                    {fileList.length >= 8 ? null : uploadButton}  
                </Upload>
                {/*显示大图 */}
                <Modal visible={previewVisible} footer={null} onCancel={this.handleCancel}>
                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                </Modal>
            </div>
        );
    }
}