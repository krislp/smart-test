import React, {Component} from 'react';
import {Form, Select, Input} from 'antd';
import PropTypes from 'prop-types';

/*
添加分类的form组件
*/
class AddForm extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }

    static propTypes = ({
        setForm: PropTypes.func.isRequired,  // 用来给父组件传递form对象的函数
        categorys: PropTypes.array.isRequired,  // 一级分类的数组
        parentId: PropTypes.string.isRequired  // 当前父分类的ID
    })

    componentWillMount () {
        this.props.setForm(this.props.form)
    }

    render() {
        const Item = Form.Item
        const Option = Select.Option
        const { getFieldDecorator } = this.props.form;
        const {categorys, parentId} = this.props
        return (
            <Form>
                <Item>
                    {getFieldDecorator('parentId', {
                        initialValue : parentId
                    })(
                        <Select>
                            <Option value='0'>一级分类</Option>
                            {
                                categorys.map((category) => (<Option value={category._id}>{category.name}</Option>))
                            }
                        </Select>
                    )}
                </Item>

                <Item>
                    {getFieldDecorator('categoryName', {
                        initialValue : '',
                        rules: [{required: true, message: '分类名称必须输入'}]
                    })(
                        <Input placeholder='请输入分类名称'></Input>
                    )}
                </Item>
            </Form>
        );
    }
}

export default Form.create()(AddForm);