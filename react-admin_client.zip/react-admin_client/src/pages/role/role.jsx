import React from 'react';

export default class Role extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div>
                Role
            </div>
        );
    }
}
