import React from 'react';
import './home.less'

export default class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div className='home'>
                欢迎使用硅谷管理系统
            </div>
        );
    }
}
