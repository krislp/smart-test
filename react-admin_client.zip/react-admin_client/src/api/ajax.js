/*
能发送异步请求的函数模块
封装axios库
函数的返回值是Promiss对象
*/

import axios from 'axios';

export default function ajax(url, data={}, type='GET') {

    return new Promise((resolve, reject) => {
        // 1.执行异步请求
        let promise;
        if(type === 'GET') {
            promise = axios.get(url, {params: data})
        }else {
            promise = axios.post(url, data)
        }
        promise.then(response => {
            // 2.请求发送成功
            resolve(response.data)
        }).catch(error => {
            // 请求发送失败
            console.log('失败', error.msg)
        })

        // 3.失败
    })
    
    
}