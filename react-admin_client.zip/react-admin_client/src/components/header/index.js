import React from 'react';
import './index.less'
import {formateDate} from '../../utils/dateUtils'
import memoryUtils from '../../utils/memoryUtils'
import storageUtils from '../../utils/storageUtils'
import {withRouter} from 'react-router-dom'
import menuList from '../../config/menuConfig'
import { Modal } from 'antd';
import LinkButton from '../link-button';

class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 
            currentTime: formateDate(Date.now())
         }
    }

    // 获取当前时间
    getTime = () => {
        this.intervalId = setInterval(()=>{
            const currentTime = formateDate(Date.now())
        this.setState({currentTime})
        }, 1000)
        
    }

    // 获取类别名称
    getTitle = () => {
        const pathname = this.props.location.pathname;
        let title
        menuList.forEach(item=>{
            if (item.key===pathname){
                title = item.title
            }else if (item.children) {
                const cItem = item.children.find(cItem => cItem.key===pathname)
                if (cItem){
                    title = cItem.title
                }
                }
            }
        )
        return title
    }

    // 退出登录
    logout = () => {
        // 弹出提示框
        Modal.confirm({
            content: '确认退出吗？',
            onOk:() => {
                // 清除数据
                memoryUtils.user = {}
                storageUtils.removeUser()
                // 跳转到登录页面
                this.props.history.replace('/login')
            },
          })

        
    }

    /*
    第一次render后执行一次
    一般在此执行异步操作：发ajax请求/启动定时器
    */
    componentDidMount = () => {
        this.getTime()
    }

    componentWillUnmount () {
        clearInterval(this.intervalId)
    }

    render() {
        const {currentTime} = this.state;
        const {username} = memoryUtils.user;
        const title = this.getTitle()

        return (
            <div className='header'>
                <div className='header-top'>
                <span>欢迎，{username}</span>
                <span><LinkButton onClick={this.logout}>退出</LinkButton></span>
                </div>
                <div className='header-bottom'>
                    <div className='header-bottom-left'>
                    <span>{title}</span>
                    </div>
                    <div className='header-bottom-right'>
                        <span>{currentTime}</span>
                        <img src='http://api.map.baidu.com/images/weather/day/qing.png' alt='weather'></img>
                        <span>晴</span>
                    </div>
                    
                </div>
            </div>
        );
    }
}

export default withRouter(Header)