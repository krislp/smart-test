const menuList = [
    {
        title: "首页",
        icon: "pie-chart",
        key: "/home"
    },
    {
        title: "商品",
        icon: "mail",
        key: "/products",
        children: [
            {
                title: "品类管理",
                icon: "mail",
                key: "/category"
            },
            {
                title: "商品管理",
                icon: "mail",
                key: "/product"
            },
        ]
    },
    {
        title: "用户管理",
        icon: "pie-chart",
        key: "/user"
    },
    {
        title: "角色管理",
        icon: "pie-chart",
        key: "/role"
    },
    {
        title: "图形图表",
        icon: "pie-chart",
        key: "/charts",
        children: [
            {
                title: "柱形图",
                icon: "pie-chart",
                key: "/charts/bar"
            },
            {
                title: "折线图",
                icon: "pie-chart",
                key: "/charts/line"
            },
            {
                title: "饼图",
                icon: "pie-chart",
                key: "/charts/pie"
            },
        ]
    },
    
]

export default menuList;