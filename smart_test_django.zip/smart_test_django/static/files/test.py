import json

from django.http import JsonResponse, FileResponse
from django.shortcuts import render

# Create your views here.
from django.views import View

from task.models import Task, Business, Fault
from utils import code_constant
from utils.common_util import resp_decorator, base_code


class TasksView(View):


    @resp_decorator
    def get(self, request):
        """查询任务信息"""
        params = request.GET
        if set(params.keys()) - {'executor', 'result'}:
            return JsonResponse(code_constant.CODE_402)
        tasks = Task.objects.filter(**params).all()
        r_code = base_code([task.values() for task in tasks])
        return JsonResponse(r_code)

    @resp_decorator
    def post(self, request):
        """新建任务"""
        params = json.loads(request.body)
        # 参数判断
        if set(params.keys()) - {'business', 'fault', 'executor'}:
            return JsonResponse(code_constant.CODE_402)
        business = params.get('business', None)
        fault = params.get('fault', None)
        if not business or not fault:
            return JsonResponse(code_constant.CODE_402)
        # 新建任务
        if Task.objects.filter(business=business, fault=fault).exists():
            return JsonResponse(code_constant.CODE_601)
        Task.objects.create(**params)
        return JsonResponse(code_constant.CODE_0)

    @resp_decorator
    def put(self, request):
        """修改任务信息"""
        params = json.loads(request.body)
        # 参数校验
        id = params.get('id', None)
        if not id:
            return JsonResponse(code_constant.CODE_402)
        check_value = {'business', 'fault', 'executor', 'parameters', 'dts'}
        if set(params.keys) - check_value:
            return JsonResponse(code_constant.CODE_402)
        business = params.get('business', [])
        fault = params.get('fault', [])
        for business_id in business:
            if not Business.objects.filter(id=business_id).exists():
                raise JsonResponse(code_constant.CODE_402)
        for fault_id in fault:
            if not Fault.objects.filter(id=fault_id).exists():
                raise JsonResponse(code_constant.CODE_402)
        # 修改任务信息
        params.pop('id')
        tasks = Task.objects.filter(id=id)
        tasks.update(**params)
        return JsonResponse(code_constant.CODE_0)

    @resp_decorator
    def download_template(self, request):
        file = open('static/files/test.txt', 'rb')
        response = FileResponse(file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="test.txt"'
        return response

class DownloadView(View):
    @resp_decorator
    def get(self, request):
        file = open('static/files/test.py', 'rb')
        response = FileResponse(file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="test.py"'
        return response


