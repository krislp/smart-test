# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.


class Business(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255, verbose_name='业务名称', unique=True)
    aw_name = models.CharField(max_length=32, verbose_name='AW名称', unique=True)

    class Meta:
        db_table = 'business'


class Fault(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255, verbose_name='故障名称', unique=True)
    aw_name = models.CharField(max_length=32, verbose_name='AW名称', unique=True)

    class Meta:
        db_table = 'fault'


class Task(models.Model):
    id = models.AutoField(primary_key=True)
    business = models.CharField(max_length=255, verbose_name='业务场景id，多个id之间用逗号隔开')
    fault = models.CharField(max_length=255, verbose_name='故障场景id，多个id之间用逗号隔开')
    executor = models.CharField(max_length=32, verbose_name='执行人')
    parameters = models.TextField(verbose_name='参数配置')
    start_time = models.DateTimeField(verbose_name='任务开始执行时间')
    end_time = models.DateTimeField(verbose_name='任务结束执行时间')
    result = models.IntegerField(verbose_name='任务执行结果，0-失败；1-成功')
    dts = models.CharField(max_length=32, verbose_name='问题单')
    info = models.TextField(verbose_name='失败信息')

    def values(self):
        business_name_list = []
        for business_id in self.business.split(','):
            business = Business.objects.filter(id=business_id)[0]
            business_name_list.append(business.name)
        business_name = ','.join(business_name_list)

        fault_name_list = []
        for fault_id in self.business.split(','):
            fault = Fault.objects.filter(id=fault_id)[0]
            fault_name_list.append(fault.name)
        fault_name = ','.join(fault_name_list)

        return {'id': self.id,
                'business': self.business,
                'business_name': business_name,
                'fault': self.fault,
                'fault_name': fault_name,
                'executor': self.executor,
                'parameters': self.parameters,
                'start_time': self.start_time,
                'end_time': self.end_time,
                'result': self.result,
                'dts': self.dts,
                'info': self.info}



