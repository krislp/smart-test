# encoding: utf-8
from django.conf.urls import url
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('/', ''),
]