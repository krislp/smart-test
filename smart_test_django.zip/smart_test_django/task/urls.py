# encoding: utf-8
from django.conf.urls import url
from django.contrib import admin
from django.urls import path

from task.views import TasksView, DownloadView

urlpatterns = [
    path('', TasksView.as_view()),
    path('download/', DownloadView.as_view())
]