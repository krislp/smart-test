# encoding: utf-8
import logging

from django.http import JsonResponse

from utils import code_constant
from utils.exception_util import CheckException

LOG = logging.getLogger(__name__)


def base_code(data, code=code_constant.CODE_0):
    """
    定义接口数据返回格式
    :param code: 错误码定义 {'code': 0, 'msg': 'success.'}
    :param data: 返回数据，字典类型
    :return: {'code': 0, 'msg': 'success.', 'data': {}}
    """
    r_code = {'data': data}
    r_code.update(**code)
    return r_code


def resp_decorator(func):

    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except CheckException as e:
            LOG.info(e.msg)
            return JsonResponse(e.msg)
        except Exception as e:
            LOG.info(e)
            return JsonResponse(code_constant.CODE_401)
    return wrapper
