# encoding: utf-8

CODE_0 = {'code': 0, 'msg': 'Success.'}
CODE_400 = {'code': 400, 'msg': 'The object is not exist.'}  # 对象不存在
CODE_401 = {'code': 401, 'msg': 'Unknown error.'}  # 未知错误
CODE_402 = {'code': 402, 'msg': 'Parameter error.'}  # 参数错误

CODE_601 = {'code': 601, 'msg': 'The task already exist.'}  # 任务已经存在
